package com.example.revathy.events;

public class Constants {
    public static String BASE_URL="http://192.168.43.238/";
}
